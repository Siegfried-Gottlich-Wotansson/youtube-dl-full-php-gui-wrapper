if you don`t know how to install this file follow this tutorial: https://www.cnet.com/how-to/how-to-install-apps-outside-of-google-play/
report any problem to p.ionut196@gmail.com