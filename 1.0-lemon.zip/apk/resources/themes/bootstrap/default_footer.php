<hr>

<div class="footer">
    <?php echo APP_NAME . ' - ' . APP_VERSION; ?><br />
	<?php echo APP_DEVELOPER; ?>
</div>
